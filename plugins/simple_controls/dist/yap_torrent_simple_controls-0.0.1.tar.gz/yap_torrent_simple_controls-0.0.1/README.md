# SimpleControls plugin for YAP Torrent


